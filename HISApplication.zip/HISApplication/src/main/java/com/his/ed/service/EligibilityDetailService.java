package com.his.ed.service;

import org.springframework.stereotype.Service;

import com.his.ed.model.EligibilityDetailModel;

public interface EligibilityDetailService {

	public EligibilityDetailModel findByCaseNum(String caseNum);
	
	public EligibilityDetailModel saveUserUpadte(EligibilityDetailModel eligibilityDetailModel);

}