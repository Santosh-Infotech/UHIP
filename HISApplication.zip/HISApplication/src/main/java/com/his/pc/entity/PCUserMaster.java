package com.his.pc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.his.util.CustomeGenerator;

import lombok.Data;
/**
 * this is used for mapping in AR_USER_MASTER
 * @author Nitish
 *
 */

@Entity
@Table(name = "DC_PLANS")
@Data
public class PCUserMaster {
	@Id 
	 @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="P_SEQ") 
	 @GenericGenerator(name="P_SEQ",strategy="com.his.util.CustomeGenerator",
	 parameters= {
			 @Parameter(name=CustomeGenerator.INCREMENT_PARAM,value="1"),
			 @Parameter(name=CustomeGenerator.VALUE_PREFIX,value="P"),
			 @Parameter(name=CustomeGenerator.NUMBER_FORMAT,value="100%d")
	 }
	 ) 
	@Column(name = "PLAN_CODE")
	private String planCode;

	@Column(name = "PLAN_NAME")
	private String planName;

	@Column(name = "PLAN_DETAILS")
	private String planDetails;
 
	
}
