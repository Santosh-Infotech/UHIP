package com.his.dc.model;

import java.sql.Timestamp;

import lombok.Data;
/**
 * this is for used model data in model class
 * @author Nitish
 *
 */
@Data
public class UserMaster {

	
	private String userDc;

	private String userId;
	
	private String firstName;

	private String lastName;

	private String surName;
	
	private String gender;
	
    private String dob;
	
	private String ssn;
   
	private Timestamp createdDate;

	private String activeSw;
}
