package com.his.pc.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.his.pc.entity.PCUserMaster;
@Repository("pcUserMasterDao")
public interface PCUserMasterDao extends JpaRepository<PCUserMaster, Serializable> {

}
