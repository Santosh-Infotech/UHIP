package com.his.al.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.his.aI.dao.AddIndvRepositry;
import com.his.aI.entity.AddIndiUserMaster;
import com.his.aI.model.ALUserMaster;

/*
 * this class is used to business operation in the case worker
 * @author Nitish
 *
 */
@Service("alService")
public class AIServiceImpl implements AIService {

 @Autowired(required=true)
	private AddIndvRepositry addIndvREpositry;
	@Override
	public ALUserMaster saveIndiv(ALUserMaster um)
	{
		AddIndiUserMaster entity=new AddIndiUserMaster();
		
	
	
		BeanUtils.copyProperties(um, entity);
		
		entity.setSsn(um.getSsn1()+um.getSsn2()+um.getSsn3());
		
		addIndvREpositry.save(entity);
		return um;

}
		
		}
	





