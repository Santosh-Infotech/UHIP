package com.his.ar.service;

import java.util.List;

import com.his.ar.model.UserMaster;

public interface ARService {
 
	public UserMaster saveUser(UserMaster um);
	
	//public List<UserMaster> findAllUsers();

}
