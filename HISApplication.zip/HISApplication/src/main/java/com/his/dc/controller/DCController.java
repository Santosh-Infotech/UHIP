package com.his.dc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.his.dc.entity.DCUserMaster;
import com.his.dc.model.UserMaster;
import com.his.dc.service.DCService;
import com.his.ps.model.PlanUserMaster;
import com.his.ps.service.PSService;
import com.his.util.AppConstants;

/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class DCController {
     
	@Autowired
	private DCService dcService;

	@Autowired
	private PSService psService;

	 @RequestMapping(value="/createCase")
		public String datasearch(@ModelAttribute(value="createCase")UserMaster um, Model model)
		{
		 initValue(model);
		model.addAttribute("dataSearch",new UserMaster());
		
	    return "caseCreate";
		}

		/**
		 * this method is used for submit the case worker form
		 * @param us
		 * @param model
		 * @return 
		 */

 @RequestMapping(value = "/getTags", method = RequestMethod.GET)
		public @ResponseBody List<UserMaster> searchApp(@RequestParam("userId") String userId,Model model) {
           
			return search(userId);

		}
      private List<UserMaster> search(String tagName) {

			List<UserMaster> result = new ArrayList<UserMaster>();
                result=dcService.findAllUsers();
			for (UserMaster tag : result) {
				if(tag.getUserId().contains(tagName))
				{
					result.add(tag);
				}
			}

			return result;
		}
      
    
      @RequestMapping(value="/createCase/search",method=RequestMethod.GET)
      public @ResponseBody Map<Integer,String> getCode(@RequestParam(name="userId") String userId)
      {
   	  
   	   UserMaster model=new UserMaster();
   		Map<Integer, String>map11 = new HashMap<>();
   	  model= dcService.findById(userId);
   	  System.out.println(model);
         map11.put(1, model.getFirstName());
         map11.put(2, model.getLastName());
         map11.put(3, model.getSurName());
         map11.put(4, model.getDob());
          map11.put(5, model.getSsn());
   		return map11;   
      }
      private void initValue(Model model) {
		   List<String>gender=new ArrayList<String>();
		  
		   gender.add("Male");
		   gender.add("Female");
		   model.addAttribute("gender",gender);
	}
     
      
      @RequestMapping(value="/createCase",method=RequestMethod.POST)
    		public String regPage(@ModelAttribute("createCase")UserMaster us,Model model)
    		{
    		model.addAttribute("planSelect",new PlanUserMaster());
    	    initValue(model);
    		UserMaster master=dcService.saveUser(us,true);
    		
            List<PlanUserMaster> plan=psService.findAllPlan();
            
            List<Object> p=new ArrayList<>();
            for(PlanUserMaster pl:plan)
            {
            	p.add(pl.getPlanName());
            }
    		
    		System.out.println(p);
    		if (master.getUserDc()!=null) {
    		   model.addAttribute(AppConstants.CASES, AppConstants.CASES_CREATE);
    			model.addAttribute(AppConstants.SUCCESS, AppConstants.CASES_CREATE);
    		    model.addAttribute("cno", master.getUserDc());
    		    model.addAttribute("apr", master.getUserId());
    		    model.addAttribute("plan", p);
    		    
    		     return "planSelect";
    			}
    			else {
    			model.addAttribute(AppConstants.ERROR, AppConstants.REG_ERROR);
    			  return"caseCreate";
    			}
    	         
    		}
      
 	 @RequestMapping(value="/viewCase")
 		public String viewCases(@ModelAttribute(value="viewCase")UserMaster um, Model model)
 		{
 		 
 		model.addAttribute("dataSearch",new UserMaster());
 		
 	    return "viewCase";
 		}
        
 	 /**
	  * this method is used to retrieve the all records 
	  */
		@RequestMapping(value="/viewCase",method=RequestMethod.GET)
		public String listAllCaseWorkers(@RequestParam(name = "cpn", defaultValue = "1") String pageNo, Model model) {

			Integer currentPageNo = 1;
			List<UserMaster> users = new ArrayList<UserMaster>();
            if (null != pageNo && !"".equals(pageNo)) {
				currentPageNo = Integer.parseInt(pageNo);
			}

			//calling Service layer method
			Page<DCUserMaster> page = dcService.findAllCase(currentPageNo - 1, AppConstants.PAGE_SIZE);
			
			//Getting Total Pages required
			int totalPages = page.getTotalPages();
			
			//Getting page specific records
			List<DCUserMaster> entities = page.getContent();

			//Converting Entity objects Model objects
			for (DCUserMaster entity : entities) {
				UserMaster um = new UserMaster();
				BeanUtils.copyProperties(entity, um);
				users.add(um);
			}
         //Storing data in model scope to access in view
			model.addAttribute("y", AppConstants.ACTIVE);
			model.addAttribute("cpn", pageNo);
			model.addAttribute("tp", totalPages);
			model.addAttribute("caseWorker", users);
			return "viewCase";
		}
		
		/**
		 * This method is used to activate case worker
		 * @param userId
		 * @return
		 */
		@RequestMapping(value = "/activateCase")
		public String activateCwProfile(@RequestParam("uid") String userDc) {
			try {
				if (null != userDc && !"".equals(userDc)) {
				System.out.println("AA:"+userDc);
					UserMaster model = dcService.findByuserDc(userDc);
					// making profile as active
					model.setActiveSw(AppConstants.ACTIVE);
					// updating record
					dcService.saveUser(model,false);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			return "redirect:viewCase";
		}
		
		/**
		 * This method is used to perform soft delete of case worker
		 */
		@RequestMapping(value = "/deleteCase")
		public String deleteCwProfile(@RequestParam("uid") String userDc) {
			try {
				if (null!= userDc && !"".equals(userDc)) {
					//int uid = Integer.parseInt(userId);
					UserMaster model = dcService.findByuserDc(userDc);
					// making profile as active
				 	model.setActiveSw(AppConstants.STR_N);
					// updating record
					dcService.saveUser(model, false);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			return "redirect:viewCase"; 
		}
		    
		
		
    	
}