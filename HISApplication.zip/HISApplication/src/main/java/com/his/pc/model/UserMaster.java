package com.his.pc.model;

import lombok.Data;
/**
 * this is for used model data in model class
 * @author Nitish
 *
 */
@Data
public class UserMaster {

	private String planCode;

	private String planName;

	private String planDetails;

	

}
