package com.his.aI.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.his.dc.entity.DCUserMaster;
import com.his.util.CustomeGenerator;
import lombok.Data;
/**
 * this is for used model data in model class
 * @author Nitish
 *
 */
@Data
@Entity
@Table(name="DC_INDV")
public class AddIndiUserMaster {

	@Id
	 @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="INDV_DC_SEQ") 
	 @GenericGenerator(name="INDV_DC_SEQ",strategy="com.his.util.CustomeGenerator",
	 parameters= {
			 @Parameter(name=CustomeGenerator.INCREMENT_PARAM,value="1"),
			 @Parameter(name=CustomeGenerator.VALUE_PREFIX,value="INDVDC"),
			 @Parameter(name=CustomeGenerator.NUMBER_FORMAT,value="100%d")
	 }
	 )
	
	@Column(name="INDV_DC_NUM")
	private String indvDc;
	
	@Column(name="DC_NUM")
	private String userDcFk;
	
	@Column(name="INDV_FNAME")
	private String firstName;
	
	@Column(name="INDV_LNAME")
	private String lastName;
	
	@Column(name="INDV_SSN")
	private String ssn;
	
	@Column(name="INDV_GENDER")
	private String gender;
	
	@Column(name="INDV_DOB")
    private String dob;


}
