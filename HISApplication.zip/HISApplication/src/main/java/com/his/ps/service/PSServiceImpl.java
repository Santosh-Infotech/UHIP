package com.his.ps.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import com.his.ps.dao.PSUserMasterDao;
import com.his.ps.entity.PSUserMaster;
import com.his.ps.model.PlanUserMaster;
/***
 * this class is used to business operation in the case worker
 * @author Nitish
 *
 */
@Service("psService")
public class PSServiceImpl implements PSService {

private static final String PLAN_RETRIEVE="SELECT PLAN_NAME FROM DC_PLANS";
	
 @Autowired(required=true)
	private PSUserMasterDao psUserMasterdao;
	
 @Autowired(required=true)
	JdbcTemplate jt;

	@Override
	public List<PlanUserMaster> findAllPlan() {
	List<PlanUserMaster> listPlan=jt.query(PLAN_RETRIEVE,new EmpExact());
		return listPlan;
	}
	private class EmpExact implements ResultSetExtractor<List<PlanUserMaster>>
	{

		@Override
		public List<PlanUserMaster> extractData(ResultSet rs) throws SQLException{
	  List<PlanUserMaster>listBo=null;
	 
	  listBo=new ArrayList<PlanUserMaster>();
	  PlanUserMaster bo=null;
	  while(rs.next())
	  {
		  bo=new PlanUserMaster();
		  bo.setPlanName(rs.getString(1));
		 
		  listBo.add(bo);
		 
		  
	  }
			return listBo;
		}

			}

	@Override
	public PlanUserMaster saveUser(PlanUserMaster um) {
     PSUserMaster entity=new PSUserMaster();
		
		/*BeanUtils.copyProperties(um, entity);
         
		psPlanUserMasterdao.save(entity);
		
		return um;*/
     BeanUtils.copyProperties(um, entity);
     PSUserMaster savedEntity = 	psUserMasterdao.save(entity);
		// setting generated pk value to model
		um.setPlanId(savedEntity.getPlanId());
		return um;

	}
	





}