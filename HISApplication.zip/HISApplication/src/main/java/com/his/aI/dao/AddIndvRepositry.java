package com.his.aI.dao;

import java.io.Serializable;

/***
 * this is class user for db operation
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.his.aI.entity.AddIndiUserMaster;
@Repository("addIndvREpositry")
public interface AddIndvRepositry extends JpaRepository<AddIndiUserMaster, Serializable> {

}
