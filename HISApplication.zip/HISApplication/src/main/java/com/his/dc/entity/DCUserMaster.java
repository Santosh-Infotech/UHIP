package com.his.dc.entity;

import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.his.aI.entity.AddIndiUserMaster;
import com.his.util.CustomeGenerator;

import lombok.Data;
/**
 * this is used for mapping in AR_USER_MASTER
 * @author Nitish
 *
 */

@Entity
@Table(name = "DC_CASES")
@Data
public class DCUserMaster {
	@Id 
	 @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="DC_SEQ") 
	 @GenericGenerator(name="DC_SEQ",strategy="com.his.util.CustomeGenerator",
	 parameters= {
			 @Parameter(name=CustomeGenerator.INCREMENT_PARAM,value="1"),
			 @Parameter(name=CustomeGenerator.VALUE_PREFIX,value="DC"),
			 @Parameter(name=CustomeGenerator.NUMBER_FORMAT,value="100%d")
	 }
	 ) 
	@Column(name = "DC_NUM")
	private String userDc;
	
	@Column(name = "USER_ID_FK")
	private String userId;
	 
	
	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;
 
	@Column(name = "SUR_NAME")
	private String surName;
	
	@Column(name = "USER_GENDER")
	private String gender;

	@Column(name = "USER_DOB")
	private String dob;

	@Column(name = "USER_SSN")
	private String ssn;
	
	@CreationTimestamp
	@Column(name = "CREATE_DT")
	private Timestamp createdDate;
  
	@Column(name = "ACTIVE_SW")
	private String activeSw;


}
