package com.his.aI.model;

import java.sql.Timestamp;

import lombok.Data;
/**
 * this is for used model data in model class
 * @author Nitish
 *
 */
@Data
public class ALUserMaster {

	
	private String userDc;
	
	private String userDcFk;
	
	private String firstName;

	private String lastName;
	
	private String ssn1;
	private String ssn2;
	private String ssn3;
	   
	private String gender;
	
    private String dob;
    
    
    
    
	
	
	
}
