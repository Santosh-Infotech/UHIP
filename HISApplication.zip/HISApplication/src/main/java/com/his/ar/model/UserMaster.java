package com.his.ar.model;

import lombok.Data;
/**
 * this is for used model data in model class
 * @author Nitish
 *
 */
@Data
public class UserMaster {

	private String userId;

	private String firstName;

	private String lastName;

	private String surName;
	
	private String email;
	
	private String phno;
	
	private String ssn1;
	
	private String ssn2;
	
	private String ssn3;
   
	private String dob;

}
