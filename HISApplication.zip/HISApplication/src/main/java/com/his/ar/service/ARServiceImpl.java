package com.his.ar.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.his.ad.entity.ADUserMaster;
import com.his.ar.dao.ARUserMasterDao;
import com.his.ar.entity.ARUserMaster;
import com.his.ar.model.UserMaster;
/***
 * this class is used to business operation in the case worker
 * @author Nitish
 *
 */
@Service("arService")
public class ARServiceImpl implements ARService {

	@Autowired(required=true)
	private ARUserMasterDao arUserMasterdao;
	@Override
	public UserMaster saveUser(UserMaster um)
	{
		ARUserMaster entity=new ARUserMaster();
		
		BeanUtils.copyProperties(um, entity);
         entity.setSsn(um.getSsn1()+um.getSsn2()+um.getSsn3());
		arUserMasterdao.save(entity);
		return um;

}
	/*@Override
	public List<UserMaster> findAllUsers() {
		
		List<UserMaster> users = new ArrayList<UserMaster>();
		List<ARUserMaster> entities = arUserMasterdao.findAll();
		for (ARUserMaster entity : entities) {
			UserMaster master = new UserMaster();
			BeanUtils.copyProperties(entity, master);
			users.add(master);
		}
		return users;
	}*/
	
		}
	





