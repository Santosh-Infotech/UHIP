package com.his.aI.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.his.aI.model.ALUserMaster;
import com.his.al.service.AIService;
import com.his.ar.service.FedralSSNClient;
import com.his.util.AppConstants;
import gov.usa.ssn.binding.IndvDetailResponse;
/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class addIndvController {
    
	@Autowired
	private AIService alService;

	@Autowired
	private FedralSSNClient ssnClient;
	
	
	 @RequestMapping(value="/addInvidual",method=RequestMethod.POST)
	 public String lunchCase(Model model,HttpServletRequest req,HttpServletResponse res) {
		 
		String dc=req.getParameter("dc");
		String fname=req.getParameter("fname");
		  String lname=req.getParameter("lname");
		String ssn1=req.getParameter("ssn1");
		String ssn2=req.getParameter("ssn2");
		String ssn3=req.getParameter("ssn3");
		String ssn=ssn1+ssn2+ssn3;
		String dob=req.getParameter("dob");
		 String gender=req.getParameter("gender");
		 
		  ALUserMaster us=new ALUserMaster();
		  us.setUserDcFk(dc);
		  us.setFirstName(fname);
		  us.setLastName(lname);
		  us.setSsn1(ssn1);
		  us.setSsn2(ssn2);
		  us.setSsn3(ssn3);
		  us.setGender(gender);
		  us.setDob(dob);
		 
		 
	  
		System.out.println("IndvArUserCaseController.lunchCase()"+dob+"   "+ssn);
		IndvDetailResponse result=null;
		System.out.println("rto");
		result=ssnClient.validateSSN(ssn, dob);
		System.out.println("Controller Response::"+result.getIndvDetail().getSsn());
		if(result.getIndvDetail().getSsn()==null &&result.getIndvDetail().getDob()==null) {
	
		model.addAttribute(AppConstants.ERROR,"SSN & DOB Invalid! You go to First all Registered SSN in Federal Govnment.");
	    model.addAttribute("cno",dc);
			}
		else {
			 ALUserMaster master=alService.saveIndiv(us);
			 if (master!=null) {
		    	  model.addAttribute("cno",dc);
			  model.addAttribute(AppConstants.SUCCESS, AppConstants.REG_SUCCESS);
		      }
				else {
					model.addAttribute("cno",dc);
				model.addAttribute(AppConstants.ERROR, AppConstants.REG_ERROR);
				}
		  
		model.addAttribute(AppConstants.SUCCESS, AppConstants.REG_SUCCESS);
	model.addAttribute("cno",dc);
	
		}
		 return "familyDetails";
	 }
	
	/*
	
  @RequestMapping(value="/addInvidual",method=RequestMethod.POST)
	public String regPage(Model model,HttpServletRequest req,HttpServletResponse res)
	{
	  
	  String dc=req.getParameter("dc");
	  String fname=req.getParameter("fname");
	  String lname=req.getParameter("lname");
	  String ssn1=req.getParameter("ssn1");
	  String ssn2=req.getParameter("ssn2");
	  String ssn3=req.getParameter("ssn3");
	  String gender=req.getParameter("gender");
	  String dob=req.getParameter("dob");
	  ALUserMaster us=new ALUserMaster();
	  us.setUserDcFk(dc);
	  us.setFirstName(fname);
	  us.setLastName(lname);
	  us.setSsn1(ssn1);
	  us.setSsn2(ssn2);
	  us.setSsn3(ssn3);
	  us.setGender(gender);
	  us.setDob(dob);
	 
	  ALUserMaster master=alService.saveIndiv(us);
      if (master!=null) {
    	  model.addAttribute("cno",dc);
	  model.addAttribute(AppConstants.SUCCESS, AppConstants.REG_SUCCESS);
      }
		else {
		model.addAttribute(AppConstants.ERROR, AppConstants.REG_ERROR);
		}
      return "familyDetails";
	}		
	/**
		 * this method is used for submit the case worker form
		 * @param us
		 * @param model
		 * @return
		 */
		
  
			
}