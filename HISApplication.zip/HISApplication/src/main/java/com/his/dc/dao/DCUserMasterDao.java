package com.his.dc.dao;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.his.ar.entity.ARUserMaster;
import com.his.dc.entity.DCUserMaster;
@Repository("dcUserMasterdao")
public interface DCUserMasterDao extends JpaRepository<DCUserMaster, Serializable> {
	
	
	/*@Query("SELECT ad FROM DCUserMaster ad where ad.userId=:userId")
	 ARUserMaster findById(@Param("userId") String userId);
 */
}
