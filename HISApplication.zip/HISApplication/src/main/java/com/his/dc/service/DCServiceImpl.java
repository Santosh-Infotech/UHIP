package com.his.dc.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.his.aI.entity.AddIndiUserMaster;
import com.his.aI.model.ALUserMaster;
import com.his.dc.dao.DCUserMasterDao;
import com.his.dc.entity.DCUserMaster;
import com.his.dc.model.UserMaster;
import com.his.util.AppConstants;
import com.his.util.Masking;
/***
 * this class is used to business operation in the case worker
 * @author Nitish
 *
 */
@Service("dcService")
public class DCServiceImpl implements DCService {
private static final String SEARCH_APR_RECORDS="SELECT FIRST_NAME,LAST_NAME,SUR_NAME,USER_DOB,USER_SSN FROM APR_USER_MASTER WHERE USER_ID=?";
private static final String SEARCH_APR="SELECT USER_ID FROM APR_USER_MASTER";
	
 @Autowired(required=true)
 private DCUserMasterDao dcUserMasterdao;
	
 @Autowired(required=true)
	JdbcTemplate jt;
	
	
	@Override
	public UserMaster findById(String userId) {
		UserMaster um=jt.queryForObject(SEARCH_APR_RECORDS, new  UserMasterRowMapper(),userId);
		return um;
	}

	private class UserMasterRowMapper implements RowMapper<UserMaster>
	{

		@Override
		public UserMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			UserMaster um=new UserMaster();
			um.setFirstName(rs.getString(1));
			um.setLastName(rs.getString(2));
			um.setSurName(rs.getString(3));
			um.setDob(rs.getString(4));
			String ssn=rs.getString(5);
			String ss=Masking.maskNumber(ssn, "xxx-xx-####");
			System.out.println(ss);
			um.setSsn(ss);
			return um;
		}
	}

	@Override
	public List<UserMaster> findAllUsers() {
	List<UserMaster> listAPR=jt.query(SEARCH_APR,new EmpExact());
		return listAPR;
	}
	private class EmpExact implements ResultSetExtractor<List<UserMaster>>
	{

		@Override
		public List<UserMaster> extractData(ResultSet rs) throws SQLException{
	  List<UserMaster>listBo=null;
	 
	  listBo=new ArrayList<UserMaster>();
	  UserMaster bo=null;
	  while(rs.next())
	  {
		  bo=new UserMaster();
		  bo.setUserId(rs.getString(1));
		 
		  listBo.add(bo);
		 
		  
	  }
			return listBo;
		}

			}

@Override
public UserMaster saveUser(UserMaster um,boolean flag) {

DCUserMaster entity=new DCUserMaster();

if(flag==true)
{
um.setActiveSw(AppConstants.ACTIVE);

BeanUtils.copyProperties(um, entity);


DCUserMaster savedEntity = dcUserMasterdao.save(entity);
// setting generated pk value to model
um.setUserDc(savedEntity.getUserDc());
}else {
	BeanUtils.copyProperties(um, entity);
	DCUserMaster savedEntity = dcUserMasterdao.save(entity);
	// setting generated pk value to model
	um.setUserDc(savedEntity.getUserDc());
}
return um;
	}
	




	@Override
	public Page<DCUserMaster> findAllCase(int pageNo, int pageSize) {
		Pageable pageble = new PageRequest(pageNo, pageSize);
		List<DCUserMaster> users = new ArrayList<DCUserMaster>();
		Page<DCUserMaster> pages = dcUserMasterdao.findAll(pageble);
		return pages;
		

	}

	@Override
	public UserMaster findByuserDc(String userId) {
		DCUserMaster entity = dcUserMasterdao.findById(userId).get();
		UserMaster model = null;
		if(entity!=null)
		{
		model=new UserMaster();
		
		BeanUtils.copyProperties(entity, model);
		}
		return model;
	}
	


}