package com.his.ed.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.his.co.batches.CoPlanReportDlyBatch;
import com.his.ed.entity.EligibilityDetailEntity;
import com.his.ed.model.EligibilityDetailModel;
import com.his.ed.service.EligibilityDetailService;
/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class EDController {
	@Autowired
	private CoPlanReportDlyBatch batch;

	@Autowired
	private EligibilityDetailService edDetailService;

	
	
	@RequestMapping("/batchTest")
	public String batchTest() {
		System.out.println("ARController.batchTest()");
		batch.init();
		return "index";
	}
	
	@RequestMapping(value="/dtrmnEligibility")
	public String dtrmnEligibilityLaunch(@ModelAttribute("dtrmnEligibility")EligibilityDetailModel eModel,Model model)
	{
model.addAttribute("dtrmnEligibility",new EligibilityDetailModel());

  return "dtrmnEligibility";
	}
		
	@RequestMapping(value="/dtrmnEligibility",method = RequestMethod.POST)
	public String dtrmnEligibility(@ModelAttribute("dtrmnEligibility")EligibilityDetailModel eModel,Model model)
	{
		eModel= edDetailService.findByCaseNum(eModel.getCaseNum());
		
		if(eModel!=null)
		{
  model.addAttribute("dtrmnEligibility",eModel);
		}
		else {
			
			model.addAttribute("caseInvalid","Invalid Case Number");	
		}

  return "dtrmnEligibility";
	}

}