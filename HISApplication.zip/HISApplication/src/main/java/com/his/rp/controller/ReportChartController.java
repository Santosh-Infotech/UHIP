package com.his.rp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.his.pc.model.UserMaster;
import com.his.pc.service.ARService;
import com.his.util.AppConstants;
/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class ReportChartController {
     
	@Autowired
	private ARService pcService;
	
  @RequestMapping(value="/reportChart")
		public String regPageLaunch()
		{
	    
	    return "reportChart";
		}

					
}