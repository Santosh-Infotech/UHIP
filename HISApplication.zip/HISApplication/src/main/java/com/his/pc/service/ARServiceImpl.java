package com.his.pc.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.his.pc.dao.PCUserMasterDao;
import com.his.pc.entity.PCUserMaster;
import com.his.pc.model.UserMaster;
/***
 * this class is used to business operation in the case worker
 * @author Nitish
 *
 */
@Service("pcService")
public class ARServiceImpl implements ARService {

	@Autowired(required=true)
	private PCUserMasterDao pcUserMasterdao;
	@Override
	public UserMaster savePlan(UserMaster um)
	{
		PCUserMaster entity=new PCUserMaster();
		
		/*BeanUtils.copyProperties(um, entity);
        pcUserMasterdao.save(entity);
		return um;*/
		BeanUtils.copyProperties(um, entity);
		PCUserMaster savedEntity = pcUserMasterdao.save(entity);
		// setting generated pk value to model
		um.setPlanCode(savedEntity.getPlanCode());

		return um;

}		}
	





