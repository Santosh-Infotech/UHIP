package com.his.ar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.his.ar.model.UserMaster;
import com.his.ar.service.ARService;
import com.his.ar.service.FedralSSNClient;
import com.his.util.AppConstants;

import gov.usa.ssn.binding.IndvDetailResponse;
/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class ARController {
     
	@Autowired
	private ARService arService;
	
	@Autowired
	private FedralSSNClient ssnClient;
	
	@RequestMapping(value="/regApp", method = RequestMethod.GET)
		public String regPageLaunch(Model model)
		{
	    
		model.addAttribute("regApp",new UserMaster());
	    return "regApp";
		}

		/**
		 * this method is used for submit the case worker form
		 * @param us
		 * @param model
		 * @return
		 */
		 @RequestMapping(value="/ssnValidator",method=RequestMethod.GET)
		 public @ResponseBody String lunchCase(@RequestParam("dob")String dob,@RequestParam("ssn")String ssn,Model model) {
			System.out.println("ArUserCaseController.lunchCase()"+dob+"   "+ssn);
			IndvDetailResponse result=null;
			System.out.println("rto");
			result=ssnClient.validateSSN(ssn, dob);
			System.out.println("Controller Response::"+result.getIndvDetail().getSsn());
			if(result.getIndvDetail().getSsn()==null &&result.getIndvDetail().getDob()==null) {
		
				return AppConstants.ERROR;
				}
			else {
				return AppConstants.SUCCESS;
			}
			
		 }
		
		  @RequestMapping(value="/regApp",method=RequestMethod.POST)
			public String regPage(@ModelAttribute("regApp")UserMaster us,Model model)
			{
			UserMaster master=arService.saveUser(us);
		    if (master!=null) {
			 model.addAttribute(AppConstants.SUCCESS, AppConstants.REG_SUCCESS);
		        }
				else {
				model.addAttribute(AppConstants.ERROR, AppConstants.REG_ERROR);
				}
		        return "regApp";
			}		
}