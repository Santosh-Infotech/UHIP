package com.his.ps.service;

import java.util.List;

import com.his.ps.model.PlanUserMaster;

public interface PSService {

   public PlanUserMaster saveUser(PlanUserMaster um);
    
   public List<PlanUserMaster> findAllPlan();
}
