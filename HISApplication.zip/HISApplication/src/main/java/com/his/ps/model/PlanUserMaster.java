package com.his.ps.model;

import lombok.Data;
/**
 * this is for used model data in model class
 * @author Nitish
 *
 */
@Data
public class PlanUserMaster {

	private String planId;
	
	private String userDc;

	private String planName;


	

}
