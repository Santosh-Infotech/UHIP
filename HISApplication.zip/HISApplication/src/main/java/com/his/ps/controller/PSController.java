package com.his.ps.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.his.co.model.CoTriggersModel;
import com.his.co.service.CoTriggersService;
import com.his.ed.model.EligibilityDetailModel;
import com.his.ed.service.EligibilityDetailService;
import com.his.ps.model.PlanUserMaster;
import com.his.ps.service.PSService;
import com.his.util.AppConstants;
/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class PSController {
     
	@Autowired
	private PSService psService;
	
	@Autowired
	private EligibilityDetailService edDetailService;
	
	@Autowired
	private CoTriggersService 	coTrgService;
	

  @RequestMapping(value="/planSelect")
		public String regPageLaunch(Model model)
		{
	    
		model.addAttribute("planSelect",new PlanUserMaster());
	    return "planSelect";
		}

		/**
		 * this method is used for submit the case worker form
		 * @param us
		 * @param model
		 * @return
		 */
		
        
  
	 @RequestMapping(value="/planSelect",method=RequestMethod.POST)
		public String planCreate(@ModelAttribute(value="planSelect")PlanUserMaster us,Model model,HttpServletRequest req,HttpServletResponse res)
		{
		 
		 List<PlanUserMaster> plan=psService.findAllPlan();
          List<Object> p=new ArrayList<>();
          
         for(PlanUserMaster pl:plan)
         {
         	p.add(pl.getPlanName());
         }
 		 PlanUserMaster planSave=psService.saveUser(us);
         if (planSave.getPlanId()!=null) {
        	
        	 
        	 model.addAttribute(AppConstants.CASES, AppConstants.CASES_CREATE);
        	 model.addAttribute(AppConstants.PLAN, AppConstants.SELECT_PLAN);
        	 
 		     model.addAttribute("cno", planSave.getUserDc());
 		     model.addAttribute("apr",req.getParameter("apr"));
 		     model.addAttribute("plan", p);
 		    model.addAttribute("select", planSave.getPlanName());
 		    
 		     return "familyDetails";
 			}
 			else {
 			model.addAttribute(AppConstants.ERROR, AppConstants.REG_ERROR);
 			  return"caseCreate";
 			}
 	    
		}
	  
	 
	
	 /**
	  * family data collection
	  * @return
	  */
	 @RequestMapping(value="/familyDetails",method=RequestMethod.POST)
		public String familyDetails(Model model,HttpServletRequest req,HttpServletResponse res)
		{
           //family********************
		 
		  String qualification1=req.getParameter("qualification1");
		  String income1=req.getParameter("income1");
		  boolean snap1=req.getParameter("snap1")!=null;
		  boolean riw1=req.getParameter("riw1")!=null;
		  boolean qhp1=req.getParameter("qhp1")!=null;
		  boolean medicare1=req.getParameter("medicare1")!=null;
		  
		  boolean snap2=req.getParameter("snap2")!=null;
		  boolean riw2=req.getParameter("riw2")!=null;
		  boolean qhp2=req.getParameter("qhp2")!=null;
		  boolean medicare2=req.getParameter("medicare2")!=null;
		  
		  boolean snap3=req.getParameter("snap3")!=null;
		  boolean riw3=req.getParameter("riw3")!=null;
		  boolean qhp3=req.getParameter("qhp3")!=null;
		  boolean medicare3=req.getParameter("medicare3")!=null;
		   
		  int total_income1=Integer.parseInt(income1);
		 EligibilityDetailModel edmodel=new EligibilityDetailModel();
		 
		 CoTriggersModel coModel=new CoTriggersModel();
		 if(edmodel!=null) {
		 
		// edmodel=edDetailService.saveUserUpadte(edmodel);		 
		 
		 
		    if(snap2||snap3||snap1&&total_income1<=5000)
		  {
			   System.out.println("snap plan is  Eligible");
			      edmodel.setCaseNum(req.getParameter("cno"));
				  edmodel.setUserId(req.getParameter("apr"));
				  edmodel.setPlanStatus(AppConstants.CASE_PLAN_STATUS);
			   edmodel.setBenefitAmt("$500");
			   edmodel.setPlanName("SNAP");
			   edDetailService.saveUserUpadte(edmodel);
			   coModel.setCaseNum(req.getParameter("cno"));
			   coModel.setTriggerStatus(AppConstants.PENDING_STATUS);
			   coTrgService.saveCoTri(coModel);
			   
		  }
		   else {
			   System.out.println("snap plan is not Eligible,bcoz income is grater than 5000");
			   edmodel.setDenialReason("income is grater than 5000");
			   edDetailService.saveUserUpadte(edmodel);

		   
		  }
		  
		  if (riw3||riw2||riw1&&qualification1.equals("Graduate"))
		  {
			  System.out.println("Riw plan is  Eligible");
		  }
		   
		 else {
				
			System.out.println("Riw plan is not Eligible ,bcoz your quly is not Graduate");
		 }
		 
			   if(qhp3||qhp2||qhp1&&qualification1.equals("Post Graduate"))
			  {
				  System.out.println("Qhp plan is  Eligible");
				  
			  }
			  else 
			  {
				  System.out.println("Qhp plan is not Eligible,bcoz your quly is not Post Graduate");	
			   
			  }
			 
			    if(medicare3||medicare2||medicare1&&qualification1.equals("Intermediate"))
				  {
				System.out.println("Medicare plan is  Eligible");
					 
				  }
			  else {
						
						 System.out.println("Medicare plan is not Eligible,bcoz your quly is not intermediate");
				   }
		model.addAttribute(AppConstants.SUCCESS,AppConstants.REG_SUCCESS);
		 }
		 model.addAttribute(AppConstants.ERROR,AppConstants.REG_ERROR);
			return "familyDetails";
		
		}



			
}