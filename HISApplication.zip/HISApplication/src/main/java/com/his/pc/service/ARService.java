package com.his.pc.service;

import com.his.pc.model.UserMaster;

public interface ARService {
 
	public UserMaster savePlan(UserMaster um);
		

}
