package com.his.dc.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.his.dc.entity.DCUserMaster;
import com.his.dc.model.UserMaster;

public interface DCService {

   public UserMaster findById(String userId);
	
   public List<UserMaster> findAllUsers();
	
   public UserMaster saveUser(UserMaster um,boolean flag);
   
   public Page<DCUserMaster> findAllCase(int pageNo,int pageSize);
   
   public UserMaster findByuserDc(String userId);
   
   
   //public UserMaster findById(Integer userId);
	/*public UserMaster findByEmail(String email);
	
    public UserMaster findByIdEdit(int cid);

	public UserMaster saveUserUpadte(UserMaster um,boolean flage);*/
}
