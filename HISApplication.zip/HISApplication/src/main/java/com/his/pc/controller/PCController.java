package com.his.pc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.his.pc.model.UserMaster;
import com.his.pc.service.ARService;
import com.his.util.AppConstants;
/**
 * this class is controller class
 * @author Nitish
 *
 */
@Controller
public class PCController {
     
	@Autowired
	private ARService pcService;
	
  @RequestMapping(value="/planCreate")
		public String regPageLaunch(Model model)
		{
	    
		model.addAttribute("planCreate",new UserMaster());
	    return "planCreate";
		}

		/**
		 * this method is used for submit the case worker form
		 * @param us
		 * @param model
		 * @return
		 */
		
	  @RequestMapping(value="/planCreate",method=RequestMethod.POST)
		public String planCreate(@ModelAttribute(value="planCreate")UserMaster us,Model model)
		{
		    UserMaster master=pcService.savePlan(us);
	        if (master.getPlanCode()!=null) {
		    model.addAttribute(AppConstants.SUCCESS, AppConstants.REG_SUCCESS);
	
			}
			else {
			model.addAttribute(AppConstants.ERROR, AppConstants.REG_ERROR);
			}
	        return "planCreate";
		}
		
	   
			
}