package com.his.al.service;

import com.his.aI.model.ALUserMaster;

public interface AIService {
 
	public ALUserMaster saveIndiv(ALUserMaster um);
    

}
